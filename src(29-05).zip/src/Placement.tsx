import React from 'react'

const Placement: React.FC = () => {
  return (
    <div>Placement</div>
  )
}

export default Placement;