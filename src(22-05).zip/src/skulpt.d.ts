declare module "skulpt" {
    export default any;
  }
  